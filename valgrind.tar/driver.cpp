/******************************************
 *  AUTHOR  :   Parham AghamohammadiAmghani
 *  Group   :   Vector
 *  CLASS   :   CS1C
 *  SECTION :   MWTTH 3:00 PM - 5:20 PM
 *  Due Date:   07/14/2019
 *****************************************/
/*
 This is an interface Program to test Vector Class.
 Test includes
 Default Constructor
 Alternatenate Constructor
 Copy Constructor.
 Move Constructor.
 push_back()
 insert()
 begin()
 end()
 [] Operator
 More..
 */
#include "vector.h"



using namespace CS1C;



int main()

{
    
    vector<int> intv; // Instantiating a vector Object with type Int

    for(int i = 0 ; i < 25 ; i++){
        std::cout << "Pushing "<<i+1 << " into the intv vector."<<std::endl;
        intv.push_back(i+1);
    }
    intv.print_vector();

    vector<int> intvCPY(intv); // Testing the copy Constructor
    std::cout << "Testing the Copy Constructor for the vector Object." <<std::endl;
    intvCPY.print_vector();
    
    for(int i = 0 ; i < 25 ; i++){ //Pushing more Items into the Vector
        std::cout << "Pushing "<<i+26 << " into the intv vector."<<std::endl;
        intv.push_back(i+26);
    }
    std::cout << "\n\nPrinting the Original Vector" <<std::endl;
    intv.print_vector();
    std::cout << "\n\nTesting the INSERT METHOD\nintv.insert(&intv[25], 99);" <<std::endl;
    intv.insert(&intv[25], 99);// Testing the Insert method;
    intv.print_vector();
    //Testing the erase Method.
    std::cout << "\n\nTesting the ERASE METHOD\n intv.erase(&intv[2]);" <<std::endl;
    std::cout << "Testing the erase METHOD on element " << 2 <<std::endl;
    intv.erase(&intv[2]);
    intv.print_vector();
    //Testing the [] operator.
    std:: cout << "\n\nTesting the  [] operator" <<std::endl;
    std:: cout << "intv[25] = " <<intv[25]<< std::endl;
    
    //Testing the MOVE constructor.
    std::cout << "\n\nTesting the Move Constructor vector<int> intV2 = std::move(intv);" <<std::endl;
    vector<int> intV2 = std::move(intv);
    std:: cout<< "Printing the New Vector" <<std::endl;
    intV2.print_vector();
    std::cout << "Printing the Old Vector" <<std::endl;
    intv.print_vector();
    //Testing the Iterator Using Begin() and Insert/
    std::cout << "\n\nTesting the Iterator Using Begin() and Insert" << std::endl;
    std::cout << "intV2.insert(intV2.begin(), *(intV2.end()));"  << std::endl;
    intV2.insert(intV2.begin(), *(intV2.end()));
    intV2.print_vector();
    
    

    
    return 0;
    
}

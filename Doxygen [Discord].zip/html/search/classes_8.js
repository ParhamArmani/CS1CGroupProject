var searchData=
[
  ['text',['text',['../classtext.html',1,'']]]
];

var searchData=
[
  ['getqpainter',['getQpainter',['../classshape.html#a121fe6dd02d98d6295d62861e0b8b1eb',1,'shape']]],
  ['getshape',['getShape',['../classshape.html#a85da91a990ccb1f9e76e56ac3ae1c2af',1,'shape']]],
  ['getx',['getX',['../classshape.html#a9ba193aac631de3898bdcd91dcd622f9',1,'shape']]],
  ['gety',['getY',['../classshape.html#a633cf1b204525d5652d1bdd3f3ac41dc',1,'shape']]]
];

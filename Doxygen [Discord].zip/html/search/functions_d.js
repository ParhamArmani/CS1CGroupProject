var searchData=
[
  ['text',['text',['../classtext.html#ac118cbf2b474df755f8e2469bba5eb00',1,'text']]]
];
